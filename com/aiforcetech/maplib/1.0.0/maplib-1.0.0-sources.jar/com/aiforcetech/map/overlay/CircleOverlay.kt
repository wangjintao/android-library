package com.aiforcetech.map.overlay

import android.graphics.Color
import com.aiforcetech.map.entity.OptElement
import com.aiforcetech.map.utils.ColorUtil.colorToRgba
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.expressions.generated.Expression
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.generated.circleLayer
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSourceAs
import java.util.UUID

/**
 *Author: WangJintao
 * Date: 2025/11/12 14:09
 **/
class CircleOverlay {

    private var mMapBoxMap: MapboxMap? = null
    private var mStyle: Style? = null

    private var registerElement: ((String, OptElement) -> Unit)? = null
    private val circleElementList: MutableList<OptElement.CircleOptElement> = mutableListOf()
    private val circleFeatureList: MutableList<Feature> = mutableListOf()

    private fun getFeatureId(): String = "circle_feature_${UUID.randomUUID()}"

    constructor(mapBoxMap: MapboxMap, style: Style, registerElement: (String, OptElement) -> Unit) {
        mMapBoxMap = mapBoxMap
        mStyle = style
        this.registerElement = registerElement
        val circleSource = geoJsonSource(CIRCLE_SOURCE_ID) {
            featureCollection(FeatureCollection.fromFeatures(circleFeatureList))
        }
        mStyle?.addSource(circleSource)

        val circleLayer = circleLayer(CIRCLE_LAYER_ID, CIRCLE_SOURCE_ID) {
            circleColor(Expression.get(KEY_CIRCLE_COLOR))
            circleRadius(Expression.get(KEY_CIRCLE_RADIUS))
            circleOpacity(1.0)
        }
        mStyle?.addLayer(circleLayer)
    }

    companion object {
        private const val CIRCLE_SOURCE_ID = "circle_source_main"
        const val CIRCLE_LAYER_ID = "circle_layer_main"

        const val KEY_CIRCLE_COLOR = "circle_color"
        const val KEY_CIRCLE_RADIUS = "circle_radius"
        const val KEY_FEATURE_ID = "feature_id"

    }

    /** 添加单个圆点 */
    fun addCircle(point: Point, color: Int, radius: Double): OptElement.CircleOptElement {
        val featureId = getFeatureId()
        val feature = Feature.fromGeometry(point).apply {
            addStringProperty(KEY_FEATURE_ID, featureId)
            addStringProperty(KEY_CIRCLE_COLOR, colorToRgba(color))
            addNumberProperty(KEY_CIRCLE_RADIUS, radius)
        }

        circleFeatureList.add(feature)
        updateSource()

        val element = OptElement.CircleOptElement(
            layerId = CIRCLE_LAYER_ID,
            sourceId = CIRCLE_SOURCE_ID,
            featureId = featureId
        )
        circleElementList.add(element)
        registerElement?.invoke(featureId, element)
        return element
    }

    /** 批量添加多个圆点 */
    fun addCircles(points: List<Point>, color: Int, radius: Double): MutableList<OptElement.CircleOptElement> {
        val elements = mutableListOf<OptElement.CircleOptElement>()
        for (point in points) {
            val element = addCircle(point, color, radius)
            elements.add(element)
        }
        updateSource()
        return elements
    }

    /** 更新 GeoJsonSource */
    private fun updateSource() {
        val source = mStyle?.getSourceAs<GeoJsonSource>(CIRCLE_SOURCE_ID)
        source?.featureCollection(FeatureCollection.fromFeatures(circleFeatureList))
    }

    /** 更新圆点位置 */
    fun updateCirclePosition(element: OptElement.CircleOptElement, newPosition: Point) {
        val index = circleFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index != -1) {
            val oldFeature = circleFeatureList[index]
            val updatedFeature = Feature.fromGeometry(newPosition)
            val props = oldFeature.properties()
            if (props != null) {
                for (entry in props.entrySet()) {
                    updatedFeature.addProperty(entry.key, entry.value)
                }
            }
            circleFeatureList[index] = updatedFeature
            updateSource()
        }
    }

    /** 更新圆点颜色 */
    fun updateCircleColor(element: OptElement.CircleOptElement, newColor: Int) {
        val index = circleFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index != -1) {
            val feature = circleFeatureList[index]
            feature.addNumberProperty(KEY_CIRCLE_COLOR, newColor)
            updateSource()
        }
    }

    /** 更新圆点半径 */
    fun updateCircleRadius(element: OptElement.CircleOptElement, newRadius: Double) {
        val index = circleFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index != -1) {
            val feature = circleFeatureList[index]
            feature.addNumberProperty(KEY_CIRCLE_RADIUS, newRadius)
            updateSource()
        }
    }

    /** 删除单个圆点 */
    fun removeCircle(element: OptElement.CircleOptElement): Boolean {
        val index = circleFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false
        circleFeatureList.removeAt(index)
        circleElementList.removeIf { it.featureId == element.featureId }
        updateSource()
        return true
    }

    /** 清除所有圆点 */
    fun clearAllCircles() {
        circleFeatureList.clear()
        circleElementList.clear()
        updateSource()
    }

    /** 释放资源 */
    fun release() {
        try {
            mStyle?.removeStyleLayer(CIRCLE_LAYER_ID)
        } catch (_: Exception) {
        }

        try {
            mStyle?.removeStyleSource(CIRCLE_SOURCE_ID)
        } catch (_: Exception) {
        }

        circleFeatureList.clear()
        circleElementList.clear()
        mMapBoxMap = null
        mStyle = null
    }


}