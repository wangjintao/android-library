package com.aiforcetech.map.entity

import android.graphics.Color
import com.mapbox.geojson.Point

/**
 *Author: WangJintao
 * Date: 2025/11/14 11:46
 **/

data class ObstacleCircle(
    val center: Point,
    val diameter: Double,
    val color: Int
) : Obstacle()

data class ObstaclePolygon(
    val points: List<Point>,
    val color: Int
) : Obstacle()

open class Obstacle

data class PolygonData(
    val outer: List<Point>,
    val obstacles: List<Obstacle>? = null,
    val strokeColor: Int = Color.BLUE,
    val strokeWidth: Double = 2.0,
    val fillColor: Int? = null
)