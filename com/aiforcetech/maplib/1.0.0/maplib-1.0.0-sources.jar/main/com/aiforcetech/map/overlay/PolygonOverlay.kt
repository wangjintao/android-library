package com.aiforcetech.map.overlay

import android.graphics.Color
import com.aiforcetech.map.entity.Obstacle
import com.aiforcetech.map.entity.ObstacleCircle
import com.aiforcetech.map.entity.ObstaclePolygon
import com.aiforcetech.map.entity.OptElement
import com.aiforcetech.map.entity.PolygonData
import com.aiforcetech.map.utils.ColorUtil.colorToRgba
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.expressions.generated.Expression
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.generated.fillLayer
import com.mapbox.maps.extension.style.layers.generated.lineLayer
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSourceAs
import com.mapbox.turf.TurfConstants
import com.mapbox.turf.TurfTransformation
import java.util.UUID

/**
 *Author: WangJintao
 * Date: 2025/11/14 11:44
 **/
class PolygonOverlay {

    private var mMapBoxMap: MapboxMap? = null
    private var mStyle: Style? = null
    private var registerElement: ((String, OptElement) -> Unit)? = null
    private val polygonFeatures = mutableListOf<Feature>()
    private val obstacleFeatures = mutableListOf<Feature>()
    private val polygonElements = mutableListOf<OptElement.PolygonOptElement>()
    private val obstacleElementMap = mutableMapOf<String, OptElement.PolygonObstacleElement>()

    constructor(mapboxMap: MapboxMap, style: Style, registerElement: (String, OptElement) -> Unit) {

        mMapBoxMap = mapboxMap
        mStyle = style
        this.registerElement = registerElement

        // 主多边形源
        mStyle?.addSource(
            geoJsonSource(POLYGON_SOURCE_ID) {
                featureCollection(FeatureCollection.fromFeatures(polygonFeatures))
            }
        )

        // 障碍物源
        mStyle?.addSource(
            geoJsonSource(OBSTACLE_SOURCE_ID) {
                featureCollection(FeatureCollection.fromFeatures(obstacleFeatures))
            }
        )

        // 多边形填充层
        mStyle?.addLayer(fillLayer(POLYGON_FILL_LAYER_ID, POLYGON_SOURCE_ID) {
            fillColor(Expression.get(KEY_FILL_COLOR))
            fillOpacity(0.5)
        })

        // 多边形边界层
        mStyle?.addLayer(lineLayer(POLYGON_LINE_LAYER_ID, POLYGON_SOURCE_ID) {
            lineColor(Expression.get(KEY_STROKE_COLOR))
            lineWidth(Expression.get(KEY_STROKE_WIDTH))
        })

        // 障碍物填充（实心）
        mStyle?.addLayer(fillLayer(OBSTACLE_FILL_LAYER_ID, OBSTACLE_SOURCE_ID) {
            fillColor(Expression.get(KEY_FILL_COLOR))
            fillOpacity(1.0)
        })

    }

    companion object {
        private const val POLYGON_SOURCE_ID = "polygon_source_main"
        private const val POLYGON_LINE_LAYER_ID = "polygon_line_layer_main"
        const val POLYGON_FILL_LAYER_ID = "polygon_fill_layer_main"

        private const val OBSTACLE_SOURCE_ID = "obstacle_source_main"
        const val OBSTACLE_FILL_LAYER_ID = "obstacle_fill_layer_main"

        const val KEY_FEATURE_ID = "polygon_feature_id"
        const val KEY_FILL_COLOR = "fill_color"
        const val KEY_STROKE_COLOR = "stroke_color"
        const val KEY_STROKE_WIDTH = "stroke_width"

        const val KEY_OBSTACLE_ID = "obstacle_id"
        const val KEY_PARENT_POLYGON_ID = "parent_polygon_id"
    }

    private fun uuid() = UUID.randomUUID().toString()

    fun addPolygon(polygonData: PolygonData): OptElement.PolygonOptElement {
        return addPolygon(polygonData.outer, polygonData.obstacles, polygonData.strokeColor, polygonData.strokeWidth,
            polygonData.fillColor)
    }

    fun addPolygon(
        outer: List<Point>,
        obstacles: List<Obstacle>? = null,
        strokeColor: Int = Color.BLUE,
        strokeWidth: Double = 2.0,
        fillColor: Int? = null
    ): OptElement.PolygonOptElement {

        val featureId = uuid()

        // 主多边形（无洞，洞另做 feature）
        val polygon = Polygon.fromLngLats(listOf(outer))

        val polygonFeature = Feature.fromGeometry(polygon).apply {
            addStringProperty(KEY_FEATURE_ID, featureId)
            addStringProperty(KEY_STROKE_COLOR, colorToRgba(strokeColor))
            addNumberProperty(KEY_STROKE_WIDTH, strokeWidth)
            addStringProperty(KEY_FILL_COLOR, colorToRgba(fillColor ?: Color.TRANSPARENT))
        }

        polygonFeatures.add(polygonFeature)
        updatePolygonSource()

        val element = OptElement.PolygonOptElement(
            polygonFeatureId = featureId,
            polygonSourceId = POLYGON_SOURCE_ID,
            fillLayerId = POLYGON_FILL_LAYER_ID,
            lineLayerId = POLYGON_LINE_LAYER_ID,
            obstacleSourceId = OBSTACLE_SOURCE_ID,
            obstacleFillLayerId = OBSTACLE_FILL_LAYER_ID
        )

        polygonElements.add(element)
        registerElement?.invoke(featureId, element)
        // 添加障碍物
        obstacles?.forEach { obs ->
            addObstacleToPolygon(element, obs)
        }

        return element
    }

    private fun updatePolygonSource() {
        mStyle?.getSourceAs<GeoJsonSource>(POLYGON_SOURCE_ID)
            ?.featureCollection(FeatureCollection.fromFeatures(polygonFeatures))
    }

    fun addObstacleToPolygon(
        polygon: OptElement.PolygonOptElement,
        obs: Obstacle
    ) {
        val obsId = uuid()
        val feature: Feature = when (obs) {

            is ObstacleCircle -> {
                Feature.fromGeometry(
                    circleToPolygon(obs.center, obs.diameter / 2)
                ).apply {
                    addStringProperty(KEY_OBSTACLE_ID, obsId)
                    addStringProperty(KEY_PARENT_POLYGON_ID, polygon.polygonFeatureId)
                    addStringProperty(KEY_FILL_COLOR, colorToRgba(obs.color))
                }
            }

            is ObstaclePolygon -> {
                Feature.fromGeometry(
                    Polygon.fromLngLats(listOf(obs.points))
                ).apply {
                    addStringProperty(KEY_OBSTACLE_ID, obsId)
                    addStringProperty(KEY_PARENT_POLYGON_ID, polygon.polygonFeatureId)
                    addStringProperty(KEY_FILL_COLOR, colorToRgba(obs.color))
                }
            }

            else -> return
        }

        obstacleFeatures.add(feature)
        updateObstacleSource()

        polygon.obstacleIds.add(obsId)
        val obstacleElement = OptElement.PolygonObstacleElement(
            obstacleId = obsId,
            parentPolygonId = polygon.polygonFeatureId
        )
        obstacleElementMap[obsId] = obstacleElement

        registerElement?.invoke(obsId, obstacleElement)
    }

    private fun circleToPolygon(center: Point, radiusMeter: Double, steps: Int = 36): Polygon {
        val finalRadiusMeter = if (radiusMeter < 2) 2.0 else radiusMeter

        return TurfTransformation.circle(
            center,
            finalRadiusMeter,
            steps,
            TurfConstants.UNIT_METERS
        )
    }

    private fun updateObstacleSource() {
        mStyle?.getSourceAs<GeoJsonSource>(OBSTACLE_SOURCE_ID)
            ?.featureCollection(FeatureCollection.fromFeatures(obstacleFeatures))
    }

    /**
     * 新增：批量添加多个多边形
     */
    fun addPolygons(list: List<PolygonData>): MutableList<OptElement.PolygonOptElement> {
        return list.mapTo(mutableListOf()) { data ->
            addPolygon(data)
        }
    }

    fun removePolygon(element: OptElement.PolygonOptElement): Boolean {
        val removedPolygon = polygonFeatures.removeIf {
            it.getStringProperty(KEY_FEATURE_ID) == element.polygonFeatureId
        }

        if (!removedPolygon) return false   // 未找到该多边形
        removeAllObstaclesForPolygon(element)
        updatePolygonSource()
        updateObstacleSource()
        polygonElements.removeIf { it.polygonFeatureId == element.polygonFeatureId }

        return true
    }

    /**
     * 根据 obstacleId 删除单个障碍物（如果障碍物存在则删除）
     * 同时会在所有 polygonElement 中移除该 obstacleId 的引用。
     */
    fun removeObstacleById(obstacleId: String): Boolean {
        // 1. 从 obstacleFeatures 中移除
        val removed = obstacleFeatures.removeIf { feat ->
            val id = try {
                feat.getStringProperty(KEY_OBSTACLE_ID)
            } catch (t: Throwable) {
                null
            }
            id == obstacleId
        }

        if (!removed) return false

        // 2. 更新 obstacle source
        updateObstacleSource()

        // 3. 从所有 polygon 元素中移除该 id（如果存在）
        polygonElements.forEach { elem ->
            elem.obstacleIds.removeIf { it == obstacleId }
        }
        obstacleElementMap.remove(obstacleId)
        return true
    }

    /**
     * 从指定地块中删除指定障碍物（由 polygonElement 和 obstacleId 指定）
     */
    fun removeObstacleFromPolygon(polygonElement: OptElement.PolygonOptElement, obstacleId: String): Boolean {
        // 先检查 polygon 元素中是否包含该 id
        if (!polygonElement.obstacleIds.contains(obstacleId)) return false

        // 从 obstacleFeatures 中移除对应的 feature（并且 parent id 匹配）
        val removed = obstacleFeatures.removeIf { feat ->
            val id = try {
                feat.getStringProperty(KEY_OBSTACLE_ID)
            } catch (t: Throwable) {
                null
            }
            val parent = try {
                feat.getStringProperty(KEY_PARENT_POLYGON_ID)
            } catch (t: Throwable) {
                null
            }
            id == obstacleId && parent == polygonElement.polygonFeatureId
        }

        if (!removed) return false

        // 更新 obstacle source
        updateObstacleSource()

        // 从 polygon element 的本地记录中移除
        polygonElement.obstacleIds.removeIf { it == obstacleId }
        obstacleElementMap.remove(obstacleId)

        return true
    }

    /**
     * 删除某个地块（polygonElement）对应的全部障碍物
     */
    fun removeAllObstaclesForPolygon(polygonElement: OptElement.PolygonOptElement): Boolean {
        val toRemoveIds = polygonElement.obstacleIds.toList()
        if (toRemoveIds.isEmpty()) return true

        // 从 obstacleFeatures 中删除 parent_polygon_id == polygonElement.polygonFeatureId
        val removedAny = obstacleFeatures.removeIf { feat ->
            val parent = try {
                feat.getStringProperty(KEY_PARENT_POLYGON_ID)
            } catch (t: Throwable) {
                null
            }
            parent == polygonElement.polygonFeatureId
        }

        updateObstacleSource()
        polygonElement.obstacleIds.forEach {
            obstacleElementMap.remove(it)
        }
        polygonElement.obstacleIds.clear()
        return removedAny
    }

    /**
     * 修改指定地块（PolygonOptElement）的填充颜色
     */
    fun updatePolygonFillColor(
        element: OptElement.PolygonOptElement,
        newColor: Int? = null
    ): Boolean {
        var changed = false
        polygonFeatures.forEach { feat ->
            val id = try {
                feat.getStringProperty(KEY_FEATURE_ID)
            } catch (e: Exception) {
                null
            }
            if (id == element.polygonFeatureId) {
                feat.addStringProperty(KEY_FILL_COLOR, colorToRgba(newColor ?: Color.TRANSPARENT))
                changed = true
            }
        }

        if (!changed) return false
        updatePolygonSource()

        return true
    }

    fun updatePolygonStrokeWidthAndColor(element: OptElement.PolygonOptElement, strokeWidth: Double? = null,
        strokeColor: Int? = null): Boolean {
        var changed = false
        polygonFeatures.forEach { feat ->
            val id = try {
                feat.getStringProperty(KEY_FEATURE_ID)
            } catch (e: Exception) {
                null
            }
            if (id == element.polygonFeatureId) {
                strokeWidth?.let { feat.addNumberProperty(KEY_STROKE_WIDTH, it) }
                strokeColor?.let { feat.addStringProperty(KEY_STROKE_COLOR, colorToRgba(it)) }
                changed = true
            }
        }

        if (!changed) return false
        updatePolygonSource()

        return true
    }

    fun clearAll() {
        polygonFeatures.clear()
        obstacleFeatures.clear()
        updatePolygonSource()
        updateObstacleSource()
        polygonElements.clear()
        obstacleElementMap.clear()
    }

    fun release() {
        listOf(
            POLYGON_FILL_LAYER_ID,
            POLYGON_LINE_LAYER_ID,
            OBSTACLE_FILL_LAYER_ID
        ).forEach {
            try {
                mStyle?.removeStyleLayer(it)
            } catch (_: Exception) {
            }
        }

        listOf(
            POLYGON_SOURCE_ID,
            OBSTACLE_SOURCE_ID
        ).forEach {
            try {
                mStyle?.removeStyleSource(it)
            } catch (_: Exception) {
            }
        }

        polygonFeatures.clear()
        obstacleFeatures.clear()
        polygonElements.clear()
        obstacleElementMap.clear()
    }


}