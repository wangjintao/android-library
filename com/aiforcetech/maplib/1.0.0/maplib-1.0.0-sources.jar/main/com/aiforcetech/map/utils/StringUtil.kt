package com.aiforcetech.map.utils

import android.content.Context

/**
 *Author: WangJintao
 * Date: 2026/4/1 11:13
 **/
object StringUtil {
    fun checkMapboxToken(context: Context) {
        val resId = context.resources.getIdentifier(
            "mapbox_access_token",
            "string",
            context.packageName
        )

        if (resId == 0) {
            throw IllegalStateException(
                "请在 App 中配置 mapbox_access_token"
            )
        }

        val token = context.getString(resId)

        if (token.isBlank()) {
            throw IllegalStateException(
                "mapbox_access_token 不能为空"
            )
        }
    }
}