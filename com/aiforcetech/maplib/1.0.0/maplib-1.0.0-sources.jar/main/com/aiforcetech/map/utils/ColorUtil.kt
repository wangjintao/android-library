package com.aiforcetech.map.utils

import android.graphics.Color

/**
 *Author: WangJintao
 * Date: 2025/11/13 17:09
 **/
object ColorUtil {

    fun colorToRgba(color: Int): String {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        val a = Color.alpha(color) / 255.0
        return "rgba($r,$g,$b,$a)"
    }

}