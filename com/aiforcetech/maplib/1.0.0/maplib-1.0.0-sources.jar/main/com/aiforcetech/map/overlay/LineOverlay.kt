package com.aiforcetech.map.overlay

import android.graphics.Color
import com.aiforcetech.map.entity.OptElement
import com.aiforcetech.map.utils.ColorUtil.colorToRgba
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.LineString
import com.mapbox.geojson.Point
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.expressions.generated.Expression
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.generated.lineLayer
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSourceAs
import java.util.UUID

/**
 *Author: WangJintao
 * Date: 2025/11/13 14:37
 **/
class LineOverlay {

    private var mMapBoxMap: MapboxMap? = null
    private var mStyle: Style? = null
    private var registerElement: ((String, OptElement) -> Unit)? = null
    private val lineFeatureList: MutableList<Feature> = mutableListOf()
    private val lineElementList: MutableList<OptElement.LineOptElement> = mutableListOf()

    private fun getFeatureId(): String = "line_${UUID.randomUUID()}"

    constructor(mapBoxMap: MapboxMap, style: Style, registerElement: (String, OptElement) -> Unit) {
        mMapBoxMap = mapBoxMap
        mStyle = style
        this.registerElement = registerElement
        val lineSource = geoJsonSource(LINE_SOURCE_ID) {
            featureCollection(FeatureCollection.fromFeatures(lineFeatureList))
        }
        mStyle?.addSource(lineSource)

        val lineLayer = lineLayer(LINE_LAYER_ID, LINE_SOURCE_ID) {
            lineColor(Expression.get(KEY_LINE_COLOR))
            lineWidth(Expression.get(KEY_LINE_WIDTH))
            lineJoin(Expression.literal("round"))
            lineCap(Expression.literal("round"))
        }
        mStyle?.addLayer(lineLayer)
    }

    companion object {
        private const val LINE_SOURCE_ID = "line_source_main"
        const val LINE_LAYER_ID = "line_layer_main"

        const val KEY_FEATURE_ID = "feature_id"
        const val KEY_LINE_COLOR = "line_color"
        const val KEY_LINE_WIDTH = "line_width"
    }

    /**
     * 添加一条轨迹线
     */
    fun addLine(points: List<Point>, color: Int = Color.BLUE, width: Double = 3.0): OptElement.LineOptElement {
        val featureId = getFeatureId()
        val feature = Feature.fromGeometry(LineString.fromLngLats(points)).apply {
            addStringProperty(KEY_FEATURE_ID, featureId)
            addStringProperty(KEY_LINE_COLOR, colorToRgba(color))
            addNumberProperty(KEY_LINE_WIDTH, width)
        }

        lineFeatureList.add(feature)
        updateSource()

        val element = OptElement.LineOptElement(
            layerId = LINE_LAYER_ID,
            sourceId = LINE_SOURCE_ID,
            featureId = featureId
        )
        lineElementList.add(element)
        registerElement?.invoke(featureId, element)
        return element
    }

    /**
     * 添加多条线
     */
    fun addLines(lines: List<List<Point>>, color: Int = Color.BLUE,
        width: Double = 3.0): MutableList<OptElement.LineOptElement> {
        val result = mutableListOf<OptElement.LineOptElement>()
        lines.forEach { points ->
            result.add(addLine(points, color, width))
        }
        return result
    }

    /**
     * 更新轨迹点（实时追加点）
     */
    fun appendPoint(element: OptElement.LineOptElement, newPoint: Point): Boolean {
        val index = lineFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false

        val feature = lineFeatureList[index]
        val geometry = feature.geometry() as? LineString ?: return false
        val newCoords = geometry.coordinates().toMutableList()
        newCoords.add(newPoint)

        val updated = Feature.fromGeometry(LineString.fromLngLats(newCoords))
        val props = feature.properties()
        if (props != null) {
            for (entry in props.entrySet()) {
                updated.addProperty(entry.key, entry.value)
            }
        }
        lineFeatureList[index] = updated
        updateSource()
        return true
    }

    /**
     * 修改线样式（颜色、宽度）
     */
    fun updateLineStyle(element: OptElement.LineOptElement, color: Int? = null, width: Double? = null): Boolean {
        val index = lineFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false

        val old = lineFeatureList[index]
        val updated = Feature.fromGeometry(old.geometry())
        val props = old.properties()
        if (props != null) {
            for (entry in props.entrySet()) {
                updated.addProperty(entry.key, entry.value)
            }
        }
        color?.let { updated.addNumberProperty(KEY_LINE_COLOR, it) }
        width?.let { updated.addNumberProperty(KEY_LINE_WIDTH, it) }

        lineFeatureList[index] = updated
        updateSource()
        return true
    }

    /**
     * 更新GeoJsonSource
     */
    private fun updateSource() {
        val source = mStyle?.getSourceAs<GeoJsonSource>(LINE_SOURCE_ID)
        source?.featureCollection(FeatureCollection.fromFeatures(lineFeatureList))
    }

    /**
     * 删除指定轨迹线
     */
    fun removeLine(element: OptElement.LineOptElement): Boolean {
        val index = lineFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false

        lineFeatureList.removeAt(index)
        lineElementList.removeIf { it.featureId == element.featureId }
        updateSource()
        return true
    }

    /**
     * 清除所有线
     */
    fun clearAllLines() {
        lineFeatureList.clear()
        lineElementList.clear()
        updateSource()
    }

    /**
     * 释放资源
     */
    fun release() {
        try {
            mStyle?.removeStyleLayer(LINE_LAYER_ID)
        } catch (_: Exception) {
        }

        try {
            mStyle?.removeStyleSource(LINE_SOURCE_ID)
        } catch (_: Exception) {
        }

        lineFeatureList.clear()
        lineElementList.clear()
        mMapBoxMap = null
        mStyle = null
    }


}