package com.aiforcetech.map.entity

import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point

/**
 *Author: WangJintao
 * Date: 2026/3/25 15:23
 **/

data class MapClickResult(
    val point: Point?,           // 点击位置
    val element: OptElement?,    // 命中的元素
    val feature: Feature?     // 原始Feature（调试/扩展用）
)