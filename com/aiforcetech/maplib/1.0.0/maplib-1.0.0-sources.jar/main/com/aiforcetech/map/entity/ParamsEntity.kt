package com.aiforcetech.map.entity

/**
 *Author: WangJintao
 * Date: 2025/11/5 14:13
 **/
data class MapConfig(
    var showCompass: Boolean = false,
    var scaleBarPosition: Int = -1,
    var showLogo: Boolean = false,
    var rotateEnabled: Boolean = false,
)
