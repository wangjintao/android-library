package com.aiforcetech.map

import android.graphics.Bitmap
import android.graphics.Color
import com.aiforcetech.map.entity.MapClickResult
import com.aiforcetech.map.entity.MapConfig
import com.aiforcetech.map.entity.OptElement
import com.aiforcetech.map.entity.PolygonData
import com.aiforcetech.map.overlay.CircleOverlay
import com.aiforcetech.map.overlay.ImageOverlay
import com.aiforcetech.map.overlay.LineOverlay
import com.aiforcetech.map.overlay.PolygonOverlay
import com.aiforcetech.map.utils.StringUtil
import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.RenderedQueryGeometry
import com.mapbox.maps.RenderedQueryOptions
import com.mapbox.maps.ScreenBox
import com.mapbox.maps.ScreenCoordinate
import com.mapbox.maps.Style
import com.mapbox.maps.coroutine.queryRenderedFeatures
import com.mapbox.maps.dsl.cameraOptions
import com.mapbox.maps.extension.localization.localizeLabels
import com.mapbox.maps.plugin.Plugin
import com.mapbox.maps.plugin.animation.MapAnimationOptions.Companion.mapAnimationOptions
import com.mapbox.maps.plugin.animation.flyTo
import com.mapbox.maps.plugin.attribution.AttributionPlugin
import com.mapbox.maps.plugin.compass.CompassPlugin
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.plugin.logo.LogoPlugin
import com.mapbox.maps.plugin.scalebar.ScaleBarPlugin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale

/**
 *Author: WangJintao
 * Date: 2025/10/31 15:43
 **/
class MapBox {

    private var mStyle: Style? = null
    private var mMapBoxMap: MapboxMap? = null

    private var imageOverlay: ImageOverlay? = null
    private var circleOverlay: CircleOverlay? = null
    private var lineOverlay: LineOverlay? = null

    private var polygonOverlay: PolygonOverlay? = null

    private val elementMap = mutableMapOf<String, OptElement>()

    private var clickJob: Job? = null

    /**
     * @param mapView 布局中的 MapView
     * @param config 地图的一些显示配置
     * @param scope 当前Activity/Fragment的LifecycleScope，后边点击查询对象在子线程中查找用
     * @param onMapClickListener 点击事件
     * @param finished 初始化结束的回调
     */
    fun initMapBox(mapView: MapView, config: MapConfig = MapConfig(), scope: CoroutineScope,
        onMapClickListener: ((MapClickResult) -> Unit)? = null, finished: () -> Unit = {}) {
        StringUtil.checkMapboxToken(mapView.context)
        mapView.run {
            getPlugin<CompassPlugin>(Plugin.MAPBOX_COMPASS_PLUGIN_ID)?.enabled = config.showCompass
            val scaleBarPlugin = getPlugin<ScaleBarPlugin>(Plugin.MAPBOX_SCALEBAR_PLUGIN_ID)
            if (config.scaleBarPosition == -1) {
                scaleBarPlugin?.enabled = false
            } else {
                scaleBarPlugin?.position = config.scaleBarPosition
            }
            getPlugin<LogoPlugin>(Plugin.MAPBOX_LOGO_PLUGIN_ID)?.enabled = config.showLogo
            getPlugin<AttributionPlugin>(Plugin.MAPBOX_ATTRIBUTION_PLUGIN_ID)?.enabled = config.showLogo
            gestures.rotateEnabled = config.rotateEnabled
            mapboxMap.let { mapboxMap ->
                mMapBoxMap = mapboxMap
                gestures.addOnMapClickListener { point ->
                    val screenPoint = mapboxMap.pixelForCoordinate(point)
                    clickJob?.cancel()
                    clickJob = scope.launch {
                        val result = queryClick(screenPoint, point)

                        onMapClickListener?.invoke(result)
                    }

                    true
                }
                mapboxMap.loadStyle(Style.SATELLITE_STREETS) { style ->
                    mStyle = style
                    style.localizeLabels(Locale.CHINESE)
                    polygonOverlay = PolygonOverlay(mapboxMap, style, ::registerElement)
                    lineOverlay = LineOverlay(mapboxMap, style, ::registerElement)
                    circleOverlay = CircleOverlay(mapboxMap, style, ::registerElement)
                    imageOverlay = ImageOverlay(mapboxMap, style, ::registerElement)
//                    Handler().postDelayed({block.invoke()},500)
                    finished.invoke()

                }
            }
        }

    }

    fun release() {
        polygonOverlay?.release()
        polygonOverlay = null
        lineOverlay?.release()
        lineOverlay = null
        circleOverlay?.release()
        circleOverlay = null
        imageOverlay?.release()
        imageOverlay = null
        mMapBoxMap = null
        mStyle = null
    }

    private fun registerElement(featureId: String, element: OptElement) {
        elementMap[featureId] = element
    }

    private suspend fun queryClick(
        screenPoint: ScreenCoordinate,
        clickPoint: Point
    ): MapClickResult {

        val expected = mMapBoxMap?.queryRenderedFeatures(
            RenderedQueryGeometry(ScreenBox(
                ScreenCoordinate(screenPoint.x - 5, screenPoint.y - 5),
                ScreenCoordinate(screenPoint.x + 5, screenPoint.y + 5)
            )),
            RenderedQueryOptions(
                listOf(
                    ImageOverlay.IMAGE_LAYER_ID,
                    CircleOverlay.CIRCLE_LAYER_ID,
                    LineOverlay.LINE_LAYER_ID,
                    PolygonOverlay.POLYGON_FILL_LAYER_ID,
                    PolygonOverlay.OBSTACLE_FILL_LAYER_ID
                ),
                null
            )
        ) ?: return MapClickResult(clickPoint, null, null)
        if (expected.isError) {
            return MapClickResult(clickPoint, null, null)
        }
        val features = expected.value ?: emptyList()
        if (features.isEmpty()) {
            return MapClickResult(clickPoint, null, null)
        }
        val feature = features.first().queriedFeature.feature

        val element = findElement(feature)

//        val layerId = queried.layers.firstOrNull()
//        when (layerId) {
//            PolygonOverlay.OBSTACLE_FILL_LAYER_ID -> {
//                // 一定是 obstacle
//            }
//            PolygonOverlay.POLYGON_FILL_LAYER_ID -> {
//                // 一定是 polygon
//            }
//        }

        return MapClickResult(clickPoint, element, feature)
    }

    private fun findElement(feature: Feature): OptElement? {

        val featureId = when {
            feature.hasProperty(ImageOverlay.KEY_FEATURE_ID) ->
                feature.getStringProperty(ImageOverlay.KEY_FEATURE_ID)

            feature.hasProperty(CircleOverlay.KEY_FEATURE_ID) ->
                feature.getStringProperty(CircleOverlay.KEY_FEATURE_ID)

            feature.hasProperty(LineOverlay.KEY_FEATURE_ID) ->
                feature.getStringProperty(LineOverlay.KEY_FEATURE_ID)

            feature.hasProperty(PolygonOverlay.KEY_FEATURE_ID) ->
                feature.getStringProperty(PolygonOverlay.KEY_FEATURE_ID)

            feature.hasProperty(PolygonOverlay.KEY_OBSTACLE_ID) ->
                feature.getStringProperty(PolygonOverlay.KEY_OBSTACLE_ID)

            else -> null
        }

        return elementMap[featureId]
    }


    /**
     * 不带动画显示地图区域
     * @param center 移动到的中心点，只进行缩放的时候可不传
     * @param zoom 地图缩放的级别，只移动显示区域时可传-1.0
     */
    fun cameraTo(center: Point? = null, zoom: Double = -1.0) {
        val cameraOptions = cameraOptions {
            if (center != null) {
                center(center)
            }
            if (zoom != -1.0) {
                zoom(zoom)
            }
        }
        mMapBoxMap?.setCamera(cameraOptions)
    }

    /**
     * 带动画移动地图显示区域
     * @param center 移动到的中心点，只进行缩放的时候可不传
     * @param zoom 地图缩放的级别，只移动显示区域时可传-1.0
     * @param duration 动画执行时间，默认5000毫秒
     */
    fun flyTo(center: Point? = null, zoom: Double = -1.0, duration: Long = 5000) {
        val cameraOptions = cameraOptions {
            if (center != null) {
                center(center)
            }
            if (zoom != -1.0) {
                zoom(zoom)
            }
        }
        mMapBoxMap?.flyTo(cameraOptions = cameraOptions, animationOptions = mapAnimationOptions {
            duration(duration)
        })
    }

    /**
     * @param element 要删除的元素,包括图片，圆点，线，多边形，多边形里的障碍物
     */
    fun removeElement(element: OptElement?) {
        element ?: return
        when (element) {
            is OptElement.ImageOptElement -> {
                imageOverlay?.removeImage(element)
                elementMap.remove(element.featureId)
            }

            is OptElement.CircleOptElement -> {
                circleOverlay?.removeCircle(element)
                elementMap.remove(element.featureId)
            }

            is OptElement.LineOptElement -> {
                lineOverlay?.removeLine(element)
                elementMap.remove(element.featureId)
            }

            is OptElement.PolygonOptElement -> {
                polygonOverlay?.removePolygon(element)
                elementMap.remove(element.polygonFeatureId)
                element.obstacleIds.forEach {
                    elementMap.remove(it)
                }

            }

            is OptElement.PolygonObstacleElement -> {
                polygonOverlay?.removeObstacleById(element.obstacleId)
                elementMap.remove(element.obstacleId)
            }
        }
    }

    /**
     * @param point 图片要添加的位置
     * @param bitmap 要显示的图片
     * @param scale 对图片缩放比例，默认为1.0，不缩放
     *
     * @return 返回添加的这个图片，后续可对其进行修改、删除操作
     */
    fun addImage(point: Point, bitmap: Bitmap, scale: Double = 1.0): OptElement.ImageOptElement? {
        return imageOverlay?.addImage(point, bitmap, scale)
    }

    /**
     * @param element 要修改的元素
     * @param newPosition 要更新到的位置
     */
    fun updateImage(element: OptElement.ImageOptElement, newPosition: Point) {
        imageOverlay?.updateImagePosition(element, newPosition)
    }

    /**
     * @param element 要修改的元素
     * @param newSize 新的大小
     */
    fun updateImageSize(element: OptElement.ImageOptElement, newSize: Double) {
        imageOverlay?.updateImageSize(element, newSize)
    }

    /**
     * 添加一个圆点
     * @param point 圆点所在位置
     * @param color 圆点颜色
     * @param radius 圆点半径
     * @return 添加的这个圆点，后续可对其进行其他操作
     */
    fun addCircle(point: Point, color: Int = Color.BLUE, radius: Double = 5.0): OptElement.CircleOptElement? {
        return circleOverlay?.addCircle(point, color, radius)
    }

    /**
     * 添加多个圆点
     * @param points 圆点所在位置集合
     * @param color 圆点颜色
     * @param radius 圆点颜色
     * @return 所添加圆点的集合
     */
    fun addCircles(points: List<Point>, color: Int = Color.BLUE,
        radius: Double = 5.0): MutableList<OptElement.CircleOptElement> {
        return circleOverlay?.addCircles(points, color, radius) ?: mutableListOf()
    }

    /**
     * 修改圆点的位置
     * @param element 要修改的圆点
     * @param newPosition 新位置
     */
    fun updateCirclePosition(element: OptElement.CircleOptElement, newPosition: Point) {
        circleOverlay?.updateCirclePosition(element, newPosition)
    }

    /**
     * 修改圆点半径
     * @param element 要修改的圆点
     * @param newRadius 新半径
     */
    fun updateCircleRadius(element: OptElement.CircleOptElement, newRadius: Double) {
        circleOverlay?.updateCircleRadius(element, newRadius)
    }

    /**
     * 修改圆点颜色
     * @param element 要修改的圆点
     * @param newColor 新颜色
     */
    fun updateCircleColor(element: OptElement.CircleOptElement, newColor: Int) {
        circleOverlay?.updateCircleColor(element, newColor)
    }

    fun addLine(points: List<Point>, color: Int = Color.BLUE, width: Double = 3.0): OptElement.LineOptElement? {
        return lineOverlay?.addLine(points, color, width)
    }

    fun addLines(lines: List<List<Point>>, color: Int = Color.BLUE,
        width: Double = 3.0): MutableList<OptElement.LineOptElement> {
        return (lineOverlay?.addLines(lines, color, width) ?: mutableListOf())
    }

    fun appendPoint(element: OptElement.LineOptElement, newPoint: Point) {
        lineOverlay?.appendPoint(element, newPoint)
    }

    fun updateLineStyle(element: OptElement.LineOptElement, color: Int? = null, width: Double? = null) {
        lineOverlay?.updateLineStyle(element, color, width)
    }

    fun addPolygon(polygonData: PolygonData): OptElement.PolygonOptElement? {
        return polygonOverlay?.addPolygon(polygonData)
    }

    fun addPolygons(polygonsData: List<PolygonData>): MutableList<OptElement.PolygonOptElement> {
        return polygonOverlay?.addPolygons(polygonsData) ?: mutableListOf()
    }

    fun updatePolygonFillColor(element: OptElement.PolygonOptElement, newColor: Int) {
        polygonOverlay?.updatePolygonFillColor(element, newColor)
    }


    fun updatePolygonStrokeWidthAndColor(element: OptElement.PolygonOptElement, strokeWidth: Double? = null,
        strokeColor: Int? = null) {
        polygonOverlay?.updatePolygonStrokeWidthAndColor(element, strokeWidth, strokeColor)
    }


    fun clear() {
        imageOverlay?.clearAllImages()
        circleOverlay?.clearAllCircles()
        lineOverlay?.clearAllLines()
        polygonOverlay?.clearAll()
    }

}

