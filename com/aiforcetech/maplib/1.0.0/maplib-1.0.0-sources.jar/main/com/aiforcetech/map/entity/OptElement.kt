package com.aiforcetech.map.entity

/**
 *Author: WangJintao
 * Date: 2025/11/5 14:22
 **/
sealed class OptElement {
    data class ImageOptElement(
        val layerId: String,
        val sourceId: String,
        val imageId: String,
        val featureId: String,
    ) : OptElement()

    data class CircleOptElement(
        val layerId: String,
        val sourceId: String,
        val featureId: String,
    ) : OptElement()

    data class LineOptElement(
        val layerId: String,
        val sourceId: String,
        val featureId: String
    ) : OptElement()

    data class PolygonOptElement(
        val polygonFeatureId: String,
        val polygonSourceId: String,
        val fillLayerId: String,
        val lineLayerId: String,
        val obstacleSourceId: String,     // 障碍物单独的 source
        val obstacleFillLayerId: String,   // 障碍物填充层
        val obstacleIds: MutableList<String> = mutableListOf()
    ) : OptElement()

    data class PolygonObstacleElement(
        val obstacleId: String,
        val parentPolygonId: String
    ) : OptElement()

}

