package com.aiforcetech.map.overlay

import android.graphics.Bitmap
import com.aiforcetech.map.entity.OptElement
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.expressions.generated.Expression
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.generated.symbolLayer
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSourceAs
import java.util.UUID

/**
 *Author: WangJintao
 * Date: 2025/11/7 15:10
 **/
class ImageOverlay {

    private var mMapBoxMap: MapboxMap? = null
    private var mStyle: Style? = null

    private var registerElement: ((String, OptElement) -> Unit)? = null
    private val imageElementList: MutableList<OptElement.ImageOptElement> = mutableListOf()
    private val imageFeatureList: MutableList<Feature> = mutableListOf()

    private fun getImageId(): String = "image_${UUID.randomUUID()}"
    private fun getFeatureId(): String = "feature_${UUID.randomUUID()}"

    constructor(mapBoxMap: MapboxMap, style: Style, registerElement: (String, OptElement) -> Unit) {
        mMapBoxMap = mapBoxMap
        mStyle = style
        this.registerElement = registerElement
        val imageSource = geoJsonSource(IMAGE_RESOURCE_ID) {
            featureCollection(FeatureCollection.fromFeatures(imageFeatureList))
        }
        mStyle?.addSource(imageSource)
        val imageLayer = symbolLayer(IMAGE_LAYER_ID, IMAGE_RESOURCE_ID) {
            iconImage(Expression.get(KEY_ICON_IMAGE))
            iconAllowOverlap(true)
            iconSize(Expression.get(KEY_ICON_SIZE))

        }
        mStyle?.addLayer(imageLayer)
    }

    companion object {
        private const val IMAGE_RESOURCE_ID = "image_resource_main"
        const val IMAGE_LAYER_ID = "image_layer_main"

        const val KEY_ICON_IMAGE = "icon_image"
        const val KEY_ICON_SIZE = "icon_size"
        const val KEY_FEATURE_ID = "feature_id"

    }


    fun addImage(point: Point, bitmap: Bitmap, scale: Double = 1.0): OptElement.ImageOptElement {
        val imageId = getImageId()
        val featureId = getFeatureId()
        mStyle?.addImage(imageId, bitmap)
        val feature = Feature.fromGeometry(point).apply {
            addStringProperty(KEY_ICON_IMAGE, imageId)
            addNumberProperty(KEY_ICON_SIZE, scale)
            addStringProperty(KEY_FEATURE_ID, featureId)
        }
//        Log.d("MAPBOX", feature.toJson())
        imageFeatureList.add(feature)
        val source = mStyle?.getSourceAs<GeoJsonSource>(IMAGE_RESOURCE_ID)
        source?.featureCollection(FeatureCollection.fromFeatures(imageFeatureList))
//        Log.d("MAPBOX", Expression.get(KEY_ICON_IMAGE).toString())
        val element =
            OptElement.ImageOptElement(layerId = IMAGE_LAYER_ID, sourceId = IMAGE_RESOURCE_ID, imageId = imageId,
                featureId = featureId)
        imageElementList.add(element)
        registerElement?.invoke(featureId, element)
        return element

    }

    fun updateImagePosition(element: OptElement.ImageOptElement, newPosition: Point) {
        val index = imageFeatureList.indexOfFirst {
            val pid = it.getStringProperty(KEY_FEATURE_ID)
            pid == element.featureId
        }
        if (index != -1) {
            val oldFeature = imageFeatureList[index]
            val updatedFeature = Feature.fromGeometry(newPosition)
            val props = oldFeature.properties()
            if (props != null) {
                val entrySet = props.entrySet()
                for (entry in entrySet) {
                    updatedFeature.addProperty(entry.key, entry.value)
                }
            }
            imageFeatureList[index] = updatedFeature
            val source = mStyle?.getSourceAs<GeoJsonSource>(element.sourceId)
            source?.featureCollection(FeatureCollection.fromFeatures(imageFeatureList))
        }
    }

    fun removeImage(element: OptElement.ImageOptElement): Boolean {
        val index = imageFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false

        imageFeatureList.removeAt(index)
        val source = mStyle?.getSourceAs<GeoJsonSource>(element.sourceId)
        source?.featureCollection(FeatureCollection.fromFeatures(imageFeatureList))
        try {
            mStyle?.removeStyleImage(element.imageId)
        } catch (t: Throwable) {
            t.printStackTrace()
        }

        imageElementList.removeIf { it.featureId == element.featureId }
        return true
    }

    fun updateImageSize(element: OptElement.ImageOptElement, scale: Double): Boolean {
        val index = imageFeatureList.indexOfFirst {
            it.getStringProperty(KEY_FEATURE_ID) == element.featureId
        }
        if (index == -1) return false
        val old = imageFeatureList[index]
        val geometry = old.geometry()
        val updated = Feature.fromGeometry(geometry)
        val props = old.properties()
        if (props != null) {
            for (entry in props.entrySet()) {
                updated.addProperty(entry.key, entry.value)
            }
        }
        updated.addNumberProperty(KEY_ICON_SIZE, scale)
        imageFeatureList[index] = updated
        val source = mStyle?.getSourceAs<GeoJsonSource>(element.sourceId)
        source?.featureCollection(FeatureCollection.fromFeatures(imageFeatureList))
        return true
    }

    fun clearAllImages() {
        imageFeatureList.clear()
        val source = mStyle?.getSourceAs<GeoJsonSource>(IMAGE_RESOURCE_ID)
        source?.featureCollection(FeatureCollection.fromFeatures(emptyList()))
        imageElementList.forEach { element ->
            mStyle?.removeStyleImage(element.imageId)
        }
        imageElementList.clear()
    }

    fun release() {
        try {
            mStyle?.removeStyleLayer(IMAGE_LAYER_ID)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            mStyle?.removeStyleSource(IMAGE_RESOURCE_ID)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            imageElementList.forEach { element ->
                mStyle?.removeStyleImage(element.imageId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        imageFeatureList.clear()
        imageElementList.clear()

        mMapBoxMap = null
        mStyle = null
    }


}